/*
 * DHT11.c
 *
 *  Created on: Jun 12, 2023
 *      Author: josep
 */

#include "DHT11.h"
#include "main.h"
#include "tim.h"
#include "gpio.h"
#include <stdio.h>

extern TIM_HandleTypeDef htim6;


void delay (uint16_t time)
{
	__HAL_TIM_SET_COUNTER(&htim6, 0);
	while ((__HAL_TIM_GET_COUNTER(&htim6)) < time);
}

void Set_Pin_Input (GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

void Set_Pin_Output (GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

void DHT11_Start (void)
{
	Set_Pin_Output (DHT11_GPIO_Port, DHT11_Pin);  //METER O PINO COMO OUTPUT
	HAL_GPIO_WritePin (DHT11_GPIO_Port, DHT11_Pin, 0);
	delay (18000);   // ESPERAR 18ms
	HAL_GPIO_WritePin (DHT11_GPIO_Port, DHT11_Pin, 1);
	delay (20);      // ESPERAR 20us
	Set_Pin_Input(DHT11_GPIO_Port, DHT11_Pin);    //METER O PINO COMO INPUT
}

uint8_t DHT11_Check_Response (void)
{
	uint8_t Response = 0;

	delay (40);

	if (!(HAL_GPIO_ReadPin (DHT11_GPIO_Port, DHT11_Pin)))
	{
		delay (80);
		if ((HAL_GPIO_ReadPin (DHT11_GPIO_Port, DHT11_Pin)))
			Response = 1;

		else
			Response = -1;
	}
	while ((HAL_GPIO_ReadPin (DHT11_GPIO_Port, DHT11_Pin)));   //ESPERAR QUE O PINO VENHA A LOW

	return Response;
}

uint8_t DHT11_Read (void)
{
	uint8_t i,j;

	for (j=0;j<8;j++)
	{
		while (!(HAL_GPIO_ReadPin (DHT11_GPIO_Port, DHT11_Pin)));   //ESPERAR QUE O PINO VENHA A HIGH

		delay (40);

		if (!(HAL_GPIO_ReadPin (DHT11_GPIO_Port, DHT11_Pin)))   // SE O PINO ESTIVER A LOW
			i&= ~(1<<(7-j));   //ESCREVER 0

		else
			i|= (1<<(7-j));  //ESCREVER 1 SE ESTIVER A HIGH

		while ((HAL_GPIO_ReadPin (DHT11_GPIO_Port, DHT11_Pin)));  //ESPERAR QUE O PINO VENHA A LOW
	}

	return i;
}

void DHT11_Output (void)
{
	uint8_t HUM_1, HUM_2, TEMP_1, TEMP_2, Presence = 0;
	uint16_t SUM, HUM_I, HUM_D, TEMP_I, TEMP_D;
	float Humidity_I = 0, Humidity_D = 0, Temperature_I = 0, Temperature_D = 0;

	DHT11_Start ();
	Presence = DHT11_Check_Response();
	HUM_1 = DHT11_Read();
	HUM_2 = DHT11_Read();
	TEMP_1 = DHT11_Read();
	TEMP_2 = DHT11_Read();
	SUM = DHT11_Read();

	HUM_I = HUM_1;
	HUM_D = HUM_2;
	TEMP_I = TEMP_1;
	TEMP_D = TEMP_2;

	Humidity_I = (float) HUM_I;
	Humidity_D = (float) HUM_D;
	Temperature_I = (float) TEMP_I;
	Temperature_D = (float) TEMP_D;

	printf ("Humdity: %.0f,%.0f \r\n", Humidity_I, Humidity_D);
	printf ("Temperature: %.0f,%.0f graus\r\n", Temperature_I, Temperature_D);
	HAL_Delay (1000);
}
