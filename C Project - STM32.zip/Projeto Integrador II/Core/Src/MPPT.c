/*
 * MPPT.c
 *
 *  Created on: Jun 12, 2023
 *      Author: josep
 */

#include "MPPT.h"
#include "adc.h"
#include "tim.h"

extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim3;;
extern uint16_t DutyCycle;
float Potencia_atual = 0, Potencia_ant = 0, Tensao_atual = 0, Tensao_ant = 0, Corrente_atual = 0, Corrente_ant = 0;

float Potencia_Max (void)
{
	uint32_t Tensao_ADC = 0, Corrente_ADC = 0;
	float Convert_Tensao_ADC = 0, Convert_Corrente_ADC = 0, Variacao_Potencia = 0, Variacao_Tensao = 0;

	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

	Tensao_ADC = ADC_Read_Channel(ADC_CHANNEL_5);
	Corrente_ADC = ADC_Read_Channel(ADC_CHANNEL_6);

	Convert_Tensao_ADC = (float) Tensao_ADC;
	Convert_Corrente_ADC = (float) Corrente_ADC;
	Tensao_atual = (3.3 * Convert_Tensao_ADC) / 4095.0;
	Corrente_atual = (3.3 * Convert_Corrente_ADC) / 4095.0;

	Potencia_atual = Tensao_atual * Corrente_atual;
	Variacao_Potencia = Potencia_atual - Potencia_ant;
	Variacao_Tensao = Tensao_atual - Tensao_ant;

	if (Variacao_Potencia > 0.0)
	{
		if (Variacao_Tensao > 0.0)
		{
			//Aumentar Duty Cycle
			if (DutyCycle < 1000)
				DutyCycle = DutyCycle + 10;
		}

		else
		{
			//Dimunuir Duty Cycle
			if (DutyCycle > 0)
				DutyCycle = DutyCycle - 10;
		}
	}

	else
	{
		if (Variacao_Tensao > 0.0)
		{
			if (DutyCycle < 1000)
				DutyCycle = DutyCycle + 10;
		}

		else
		{
			//Dimunuir Duty Cycle
			if (DutyCycle > 0)
				DutyCycle = DutyCycle - 10;
		}
	}

	Potencia_ant = Potencia_atual;
	Tensao_ant = Tensao_atual;

	return Potencia_atual;
}

