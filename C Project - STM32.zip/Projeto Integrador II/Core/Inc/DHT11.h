/*
 * DHT11.h
 *
 *  Created on: Jun 12, 2023
 *      Author: josep
 */

#ifndef INC_DHT11_H_
#define INC_DHT11_H_

#endif /* INC_DHT11_H_ */
