/*
 * MPPT.h
 *
 *  Created on: Jun 12, 2023
 *      Author: josep
 */

#ifndef INC_MPPT_H_
#define INC_MPPT_H_

float Potencia_Max (void);

#endif /* INC_MPPT_H_ */
